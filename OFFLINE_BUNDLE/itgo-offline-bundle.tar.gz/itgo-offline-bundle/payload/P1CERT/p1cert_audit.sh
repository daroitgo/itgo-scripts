#!/usr/bin/env bash
# shellcheck shell=bash
# Read-only P1 certificate audit. Targets are read from the versioned payload.

if [ -z "${BASH_VERSION:-}" ]; then
  exec /usr/bin/env bash "$0" "$@"
fi
set -eu

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -r "$SCRIPT_DIR/p1cert.version" ]; then
  MODULE_DIR="$SCRIPT_DIR"
else
  MODULE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
fi
VERSION_FILE="$MODULE_DIR/p1cert.version"
LOG_DIR="$MODULE_DIR/logs"
STATE_DIR="$MODULE_DIR/state"
STATE_FILE="$STATE_DIR/p1cert-state"
[ -r "$VERSION_FILE" ] && . "$VERSION_FILE"
P1CERT_VERSION="${P1CERT_VERSION:-UNKNOWN}"

P1_USED=no
PROFILE=UNKNOWN
ENDPOINT=""
SERVER_TRUST_PATH=""
SERVER_TRUST_TYPE=UNKNOWN
SERVER_TRUST_PASSWORD=""
SERVER_TRUST_CONTAINER=""
CLIENT_TLS_PATH=""
CLIENT_TLS_TYPE=UNKNOWN
CLIENT_WSS_PATH=""
CLIENT_WSS_TYPE=UNKNOWN
SOURCE_TYPE=UNKNOWN
SOURCE_PATH=""
SOURCE_PASSWORD=""
SOURCE_CONTAINER=""
APP_DIR=""
PAYLOAD_ID=""
PAYLOAD_CHANGE_AT=""
SERVER_CERT_MODE=""
PRESERVE_WSS=""
PAYLOAD_ZIP=""
PAYLOAD_TMP=""
PAYLOAD_ERROR=""
TARGET_ROOT_FP=""
TARGET_TLS_FP=""
TARGET_WSS_FP=""
SERVER_CERT_FP=""
TARGET_ROOT_PRESENT=unknown
TARGET_TLS_PRESENT=unknown
TARGET_WSS_PRESENT=unknown
SERVER_CERT_TARGET_PRESENT=unknown
JAVA_DETECTED=no
JAVA_LABEL='NIE WYKRYTO'
JAVA_CACERTS=""
JAVA_TARGET_ROOT_PRESENT=unknown
JAVA_TARGET_TLS_PRESENT=unknown
JAVA_TARGET_WSS_PRESENT=unknown
AUDIT_RESULT=OK

# Tests can mirror /srv below an isolated directory.  Production keeps paths
# unchanged; displayed and persisted paths are always the logical paths.
fs_path() {
  case "${P1CERT_FS_ROOT:-}" in
    '') printf '%s\n' "$1" ;;
    *) printf '%s%s\n' "${P1CERT_FS_ROOT%/}" "$1" ;;
  esac
}

log() {
  printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG_FILE"
}
payload_fail() {
  PAYLOAD_ERROR="$1"
  AUDIT_RESULT=UNKNOWN
  log "payload error: $1"
}
cleanup() {
  if [ -n "$PAYLOAD_TMP" ] && [ -d "$PAYLOAD_TMP" ]; then
    rm -rf "$PAYLOAD_TMP"
  fi
}
trap cleanup EXIT HUP INT TERM
yesno() {
  case "$1" in
    yes) printf TAK ;;
    no) printf NIE ;;
    *) printf NIEZNANE ;;
  esac
}

config_value() {
  local file="$1" key="$2" value
  [ -r "$file" ] || return 0
  value="$(awk -v wanted="$key" '$0 ~ "^[[:space:]]*(-[[:space:]]+)?(export[[:space:]]+)?" wanted "[[:space:]]*=" { sub("^[[:space:]]*(-[[:space:]]+)?(export[[:space:]]+)?" wanted "[[:space:]]*=[[:space:]]*", ""); sub(/[[:space:]]+$/, ""); print; exit }' "$file")"
  case "$value" in
    \"*\") value="${value#\"}"; value="${value%\"}" ;;
    \'*\') value="${value#\'}"; value="${value%\'}" ;;
  esac
  printf '%s\n' "$value"
}

resolve_config_path() {
  local base_dir="$1" value="$2"
  case "$value" in
    /*)
      printf '%s\n' "$value"
      ;;
    *)
      while [ "${value#./}" != "$value" ]; do
        value="${value#./}"
      done
      printf '%s/%s\n' "${base_dir%/}" "$value"
      ;;
  esac
}

docker_backend() {
  if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
    printf '%s\n' docker-compose-plugin
  elif command -v docker-compose >/dev/null 2>&1; then
    printf '%s\n' docker-compose-legacy
  elif command -v docker >/dev/null 2>&1; then
    printf '%s\n' docker-without-compose
  else
    printf '%s\n' docker-unavailable
  fi
}

safe_payload_path() {
  case "$1" in ""|/*|*\\*|*".."*|*[!A-Za-z0-9._/-]*) return 1 ;; esac
  case "/$1/" in */../*|*/./*) return 1 ;; esac
  return 0
}
find_payload() {
  local path
  for path in "$MODULE_DIR/certs/p1-production-certs.zip" "$SCRIPT_DIR/certs/p1-production-certs.zip"; do
    if [ -r "$path" ]; then
      PAYLOAD_ZIP="$path"
      return 0
    fi
  done
  return 1
}

manifest_value() {
  awk -F= -v wanted="$2" '$1 == wanted { print substr($0, length(wanted) + 2); exit }' "$1"
}
validate_manifest() {
  local file="$1" key value
  awk '/^[[:space:]]*($|#)/ { next } /^[A-Z_]+=[^[:cntrl:]]*$/ { key=$0; sub(/=.*/, "", key); if (key !~ /^(PAYLOAD_SCHEMA|PAYLOAD_ID|CHANGE_AT|TARGET_ROOT_FILE|TARGET_TLS_FILE|TARGET_WSS_FILE|SERVER_CERT_MODE|SERVER_CERT_FILE|PRESERVE_WSS)$/ || ++seen[key] > 1) exit 1; next } { exit 1 }' "$file" || return 1
  for key in PAYLOAD_SCHEMA PAYLOAD_ID TARGET_ROOT_FILE TARGET_TLS_FILE TARGET_WSS_FILE SERVER_CERT_MODE PRESERVE_WSS CHANGE_AT; do value="$(manifest_value "$file" "$key")"; [ -n "$value" ] || return 1; done
  [ "$(manifest_value "$file" PAYLOAD_SCHEMA)" = 1 ] || return 1
  case "$(manifest_value "$file" SERVER_CERT_MODE)" in preserve|replace) ;; *) return 1 ;; esac
  case "$(manifest_value "$file" PRESERVE_WSS)" in true|false) ;; *) return 1 ;; esac
  [ "$(manifest_value "$file" SERVER_CERT_MODE)" != replace ] || [ -n "$(manifest_value "$file" SERVER_CERT_FILE)" ] || return 1
}
extract_file() {
  local entry="$1" destination="$2"
  safe_payload_path "$entry" || return 1
  unzip -p "$PAYLOAD_ZIP" "$entry" > "$destination" 2>/dev/null
  [ -s "$destination" ]
}
read_certificate() {
  local file="$1" type="$2" data fingerprint subject issuer not_before not_after
  data="$(openssl x509 -in "$file" -noout -fingerprint -sha256 -subject -issuer -startdate -enddate 2>/dev/null)" || \
    data="$(openssl x509 -inform DER -in "$file" -noout -fingerprint -sha256 -subject -issuer -startdate -enddate 2>/dev/null)" || return 1
  fingerprint="$(printf '%s\n' "$data" | awk -F= '{ field=$1; gsub(/^[[:space:]]+|[[:space:]]+$/, "", field); if (tolower(field) == "sha256 fingerprint") { print toupper($2); exit } }')"
  subject="$(printf '%s\n' "$data" | sed -n 's/^subject=//p')"; issuer="$(printf '%s\n' "$data" | sed -n 's/^issuer=//p')"
  not_before="$(printf '%s\n' "$data" | sed -n 's/^notBefore=//p')"; not_after="$(printf '%s\n' "$data" | sed -n 's/^notAfter=//p')"
  [ -n "$fingerprint" ] && [ -n "$subject" ] && [ -n "$issuer" ] && [ -n "$not_before" ] && [ -n "$not_after" ] || return 1
  case "$type" in ROOT) TARGET_ROOT_FP="$fingerprint" ;; TLS) TARGET_TLS_FP="$fingerprint" ;; WSS) TARGET_WSS_FP="$fingerprint" ;; SERVER) SERVER_CERT_FP="$fingerprint" ;; esac
}
load_payload() {
  local manifest root_file tls_file wss_file server_file
  command -v unzip >/dev/null 2>&1 || { payload_fail 'unzip unavailable'; return; }
  command -v openssl >/dev/null 2>&1 || { payload_fail 'openssl unavailable'; return; }
  find_payload || { payload_fail 'payload ZIP missing'; return; }
  PAYLOAD_TMP="$(mktemp -d "${TMPDIR:-/tmp}/p1cert.XXXXXX")" || { payload_fail 'cannot create temporary directory'; return; }
  manifest="$PAYLOAD_TMP/manifest.env"; extract_file manifest.env "$manifest" || { payload_fail 'manifest.env missing from payload'; return; }
  validate_manifest "$manifest" || { payload_fail 'invalid manifest.env'; return; }
  PAYLOAD_ID="$(manifest_value "$manifest" PAYLOAD_ID)"; PAYLOAD_CHANGE_AT="$(manifest_value "$manifest" CHANGE_AT)"
  SERVER_CERT_MODE="$(manifest_value "$manifest" SERVER_CERT_MODE)"; PRESERVE_WSS="$(manifest_value "$manifest" PRESERVE_WSS)"
  root_file="$(manifest_value "$manifest" TARGET_ROOT_FILE)"; tls_file="$(manifest_value "$manifest" TARGET_TLS_FILE)"; wss_file="$(manifest_value "$manifest" TARGET_WSS_FILE)"; server_file="$(manifest_value "$manifest" SERVER_CERT_FILE)"
  safe_payload_path "$root_file" && safe_payload_path "$tls_file" && safe_payload_path "$wss_file" || { payload_fail 'unsafe target path in manifest'; return; }
  extract_file "$root_file" "$PAYLOAD_TMP/root.pem" || { payload_fail 'target RootCA missing from payload'; return; }
  extract_file "$tls_file" "$PAYLOAD_TMP/tls.pem" || { payload_fail 'target SubCA TLS missing from payload'; return; }
  extract_file "$wss_file" "$PAYLOAD_TMP/wss.pem" || { payload_fail 'target SubCA WSS missing from payload'; return; }
  read_certificate "$PAYLOAD_TMP/root.pem" ROOT || { payload_fail 'cannot read target RootCA certificate'; return; }
  read_certificate "$PAYLOAD_TMP/tls.pem" TLS || { payload_fail 'cannot read target SubCA TLS certificate'; return; }
  read_certificate "$PAYLOAD_TMP/wss.pem" WSS || { payload_fail 'cannot read target SubCA WSS certificate'; return; }
  if [ "$SERVER_CERT_MODE" = replace ]; then safe_payload_path "$server_file" || { payload_fail 'unsafe server certificate path in manifest'; return; }; extract_file "$server_file" "$PAYLOAD_TMP/server.pem" || { payload_fail 'target server certificate missing from payload'; return; }; read_certificate "$PAYLOAD_TMP/server.pem" SERVER || { payload_fail 'cannot read target server certificate'; return; }; fi
}

path_from_p1adapter() {
  local file="$1"
  local folder
  local store

  folder="$(config_value "$file" KEYSTORES_FOLDER)"
  store="$(config_value "$file" KEYSTORE_FILE)"
  SOURCE_TYPE="$(config_value "$file" KEYSTORE_TYPE)"
  SOURCE_PASSWORD="$(config_value "$file" KEYSTORE_PASSWORD)"
  [ -n "$SOURCE_TYPE" ] || SOURCE_TYPE=JKS

  if [ -n "$store" ]; then
    case "$store" in
      /*) SOURCE_PATH="$store" ;;
      *) SOURCE_PATH="$(resolve_config_path /srv/P1ADAPTER "${folder%/}/$store")" ;;
    esac
  fi
}

sync_legacy_source() {
  SOURCE_PATH="$SERVER_TRUST_PATH"
  SOURCE_TYPE="$SERVER_TRUST_TYPE"
  SOURCE_PASSWORD="$SERVER_TRUST_PASSWORD"
}

compose_file() {
  local app_dir="$1" file
  for file in docker-compose.yml compose.yml compose.yaml; do
    [ -r "$(fs_path "$app_dir/$file")" ] && { printf '%s\n' "$app_dir/$file"; return 0; }
  done
  return 1
}

detect_p1adapter() {
  local logical=/srv/P1ADAPTER file value
  [ -d "$(fs_path "$logical")" ] || return 1
  APP_DIR="$logical"; PROFILE=P1ADAPTER
  path_from_p1adapter "$(fs_path "$logical/.env")"
  if [ -n "$SOURCE_PATH" ]; then
    P1_USED=yes; SERVER_TRUST_PATH="$SOURCE_PATH"; SERVER_TRUST_TYPE="$SOURCE_TYPE"; SERVER_TRUST_PASSWORD="$SOURCE_PASSWORD"; return 0
  fi
  for file in "$logical/docker-compose.yml" "$logical/compose.yml" "$logical/compose.yaml"; do
    [ -r "$(fs_path "$file")" ] || continue
    value="$(config_value "$(fs_path "$file")" KEYSTORE_FILE)"
    if [ -n "$value" ]; then
      SERVER_TRUST_PATH="$(resolve_config_path "$APP_DIR" "$value")"; SERVER_TRUST_TYPE="$(config_value "$(fs_path "$file")" KEYSTORE_TYPE)"; [ -n "$SERVER_TRUST_TYPE" ] || SERVER_TRUST_TYPE=JKS; P1_USED=yes; sync_legacy_source; return 0
    fi
  done
  P1_USED=unknown; AUDIT_RESULT=UNKNOWN; return 0
}

detect_p1cer() {
  local logical=/srv/P1CER file value
  [ -d "$(fs_path "$logical")" ] || return 1
  APP_DIR="$logical"; PROFILE=P1CER
  for file in "$logical/docker-compose.yml" "$logical/compose.yml" "$logical/compose.yaml"; do
    [ -r "$(fs_path "$file")" ] || continue
    SERVER_TRUST_PATH="$(config_value "$(fs_path "$file")" CSIOZ_EREJESTRACJA_TRUSTSTORE_PATH)"; SERVER_TRUST_PASSWORD="$(config_value "$(fs_path "$file")" CSIOZ_EREJESTRACJA_TRUSTSTORE_PASSWORD)"; SERVER_TRUST_TYPE="$(config_value "$(fs_path "$file")" CSIOZ_EREJESTRACJA_TRUSTSTORE_TYPE)"
    if [ -n "$SERVER_TRUST_PATH" ]; then SERVER_TRUST_PATH="$(resolve_config_path "$APP_DIR" "$SERVER_TRUST_PATH")"; [ -n "$SERVER_TRUST_TYPE" ] || SERVER_TRUST_TYPE=PKCS12; P1_USED=yes; sync_legacy_source; return 0; fi
    for value in CSIOZ_EREJESTRACJA_SSL_KEYSTORE_PATH CSIOZ_EREJESTRACJA_TLS_KEYSTORE_PATH CSIOZ_EREJESTRACJA_WSS_KEYSTORE_PATH; do
      SERVER_TRUST_PATH="$(config_value "$(fs_path "$file")" "$value")"
      case "$SERVER_TRUST_PATH" in *.pem|*.PEM|*.cer|*.CER|*.crt|*.CRT) SERVER_TRUST_PATH="$(resolve_config_path "$APP_DIR" "$SERVER_TRUST_PATH")"; SERVER_TRUST_TYPE=PEM; P1_USED=yes; sync_legacy_source; return 0 ;; esac
    done
  done
  P1_USED=unknown; AUDIT_RESULT=UNKNOWN; return 0
}

detect_classic_pi() {
  local app=/srv/IntegrationPlatform_ERECEPTY apache cfg sign
  apache="$app/apache-tomcat/webapps/p1-war/WEB-INF"
  cfg="$apache/appConfig.properties"; sign="$apache/classes/p1Sign.properties"
  [ -r "$(fs_path "$cfg")" ] || return 1
  APP_DIR="$app"; PROFILE=CLASSIC_PI; P1_USED=yes
  ENDPOINT="$(config_value "$(fs_path "$cfg")" p1.host.url)"
  SERVER_TRUST_PATH="$(config_value "$(fs_path "$cfg")" SSL.patch)"; SERVER_TRUST_TYPE=PEM
  CLIENT_TLS_PATH="$(config_value "$(fs_path "$cfg")" TLS.patch)"; CLIENT_TLS_TYPE=PKCS12
  CLIENT_WSS_PATH="$(config_value "$(fs_path "$sign")" org.apache.ws.security.crypto.merlin.keystore.file)"
  CLIENT_WSS_TYPE="$(config_value "$(fs_path "$sign")" org.apache.ws.security.crypto.merlin.keystore.type)"; [ -n "$CLIENT_WSS_TYPE" ] || CLIENT_WSS_TYPE=UNKNOWN
  sync_legacy_source
}

detect_medical_events() {
  local app=/srv/zm_docker env compose folder server client medevt
  env="$app/.env"; compose="$(compose_file "$app" || true)"
  [ -r "$(fs_path "$env")" ] && [ -n "$compose" ] || return 1
  APP_DIR="$app"; PROFILE=MEDICAL_EVENTS_DOCKER; P1_USED=yes
  folder="$(config_value "$(fs_path "$env")" KEYSTORES_FOLDER)"; server="$(config_value "$(fs_path "$env")" FHIR_SSL_CERT_FILE)"; client="$(config_value "$(fs_path "$env")" ZDM_KEYSTORE_FILE)"
  [ -n "$server" ] && SERVER_TRUST_PATH="$(resolve_config_path "$app" "${folder%/}/$server")"; SERVER_TRUST_TYPE=PEM
  [ -n "$client" ] && CLIENT_TLS_PATH="$(resolve_config_path "$app" "${folder%/}/$client")"; CLIENT_TLS_TYPE=JKS
  medevt="$app/medevt.env"; ENDPOINT="$(config_value "$(fs_path "$medevt")" FHIR_SERVER_URL)"; [ -n "$ENDPOINT" ] || ENDPOINT="$(config_value "$(fs_path "$medevt")" AUTHORIZATION_URL)"
  sync_legacy_source
}

detect_ekrn() {
  local app=/srv/EKRN compose
  compose="$(compose_file "$app" || true)"; [ -n "$compose" ] || return 1
  APP_DIR="$app"; PROFILE=EKRN; P1_USED=yes
  ENDPOINT="$(config_value "$(fs_path "$compose")" EKRN_URL)"
  SERVER_TRUST_PATH="$(config_value "$(fs_path "$compose")" EKRN_SSL_TRUSTSTORE_PATH)"; SERVER_TRUST_TYPE="$(config_value "$(fs_path "$compose")" EKRN_SSL_TRUSTSTORE_TYPE)"; SERVER_TRUST_PASSWORD="$(config_value "$(fs_path "$compose")" EKRN_SSL_TRUSTSTORE_PASSWORD)"
  CLIENT_WSS_PATH="$(config_value "$(fs_path "$compose")" EKRN_SSL_KEYSTORE_PATH)"; CLIENT_WSS_TYPE="$(config_value "$(fs_path "$compose")" EKRN_SSL_KEYSTORE_TYPE)"
  [ -n "$SERVER_TRUST_TYPE" ] || SERVER_TRUST_TYPE=UNKNOWN; [ -n "$CLIENT_WSS_TYPE" ] || CLIENT_WSS_TYPE=UNKNOWN
  sync_legacy_source
}

detect_source() {
  detect_p1adapter && return 0
  detect_p1cer && return 0
  detect_classic_pi && return 0
  detect_medical_events && return 0
  detect_ekrn && return 0
  return 0
}

map_mounts_to_container_path() {
  local mounts="$1"
  local source
  local destination
  local best_source=""
  local best_destination=""

  while IFS='|' read -r source destination; do
    [ -n "$source" ] && [ -n "$destination" ] || continue
    case "$SOURCE_PATH" in
      "$source"|"$source"/*)
        if [ "${#source}" -gt "${#best_source}" ]; then
          best_source="$source"
          best_destination="$destination"
        fi
        ;;
    esac
  done <<EOF
$mounts
EOF
  [ -n "$best_source" ] || return 1
  printf '%s\n' "${best_destination%/}${SOURCE_PATH#$best_source}"
}

container_path() {
  local container="$1"
  local mounts
  mounts="$(docker inspect --format '{{range .Mounts}}{{println .Source "|" .Destination}}{{end}}' "$container" 2>/dev/null || true)"
  map_mounts_to_container_path "$mounts"
}
find_container() {
  local container
  local project_dir
  command -v docker >/dev/null 2>&1 || return 0
  for container in $(docker ps --format '{{.ID}}' 2>/dev/null); do
    if container_path "$container" >/dev/null 2>&1; then
      printf '%s\n' "$container"
      return 0
    fi
  done
  if [ -n "$APP_DIR" ]; then
    for container in $(docker ps --format '{{.ID}}' 2>/dev/null); do
      project_dir="$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' "$container" 2>/dev/null || true)"
      if [ "$project_dir" = "$APP_DIR" ]; then
        printf '%s\n' "$container"
        return 0
      fi
    done
  fi
  docker ps --format '{{.ID}} {{.Names}}' 2>/dev/null | awk '/p1adapter|p1cer|medicalEventsP1|medicaleventsp1|ekrn|P1ADAPTER|P1CER|EKRN/ {print $1; exit}'
}

mark_targets() {
  local data="$1"
  if printf '%s\n' "$data" | grep -F -q "$TARGET_ROOT_FP"; then TARGET_ROOT_PRESENT=yes; else TARGET_ROOT_PRESENT=no; fi
  if printf '%s\n' "$data" | grep -F -q "$TARGET_TLS_FP"; then TARGET_TLS_PRESENT=yes; else TARGET_TLS_PRESENT=no; fi
  if printf '%s\n' "$data" | grep -F -q "$TARGET_WSS_FP"; then TARGET_WSS_PRESENT=yes; else TARGET_WSS_PRESENT=no; fi
}

audit_pem() {
  local output pem_file cert_dir cert
  pem_file="$(fs_path "$SERVER_TRUST_PATH")"
  command -v openssl >/dev/null 2>&1 && [ -r "$pem_file" ] || return 1
  cert_dir="$(mktemp -d "${TMPDIR:-/tmp}/p1cert-pem.XXXXXX")" || return 1
  # openssl x509 reads only the first certificate in a PEM bundle.  Split it
  # with POSIX awk so every certificate is checked on OL7 as well.
  awk -v prefix="$cert_dir/cert-" '/-----BEGIN CERTIFICATE-----/ { n++; in_cert=1 } in_cert { print > (prefix n ".pem") } /-----END CERTIFICATE-----/ { close(prefix n ".pem"); in_cert=0 }' "$pem_file"
  output=""
  for cert in "$cert_dir"/cert-*.pem; do
    [ -r "$cert" ] || continue
    output="$output$(openssl x509 -in "$cert" -noout -fingerprint -sha256 2>/dev/null || true)
"
  done
  rm -rf "$cert_dir"
  [ -n "$output" ] || return 1
  mark_targets "$output"
}
audit_store() {
  local keytool_bin=""
  local store_path
  local output
  store_path="$(fs_path "$SERVER_TRUST_PATH")"

  if command -v keytool >/dev/null 2>&1 && [ -r "$store_path" ]; then
    keytool_bin=keytool
  else
    SOURCE_CONTAINER="$(find_container)"
    if [ -z "$SOURCE_CONTAINER" ] || ! docker exec "$SOURCE_CONTAINER" sh -c 'command -v keytool >/dev/null 2>&1' >/dev/null 2>&1; then
      return 1
    fi
    store_path="$(container_path "$SOURCE_CONTAINER")"
    output="$(printf '%s\n' "$SERVER_TRUST_PASSWORD" | docker exec -i "$SOURCE_CONTAINER" keytool -list -v -keystore "$store_path" -storetype "$SERVER_TRUST_TYPE" 2>/dev/null || true)"
    [ -n "$output" ] || return 1
    mark_targets "$output"
    return 0
  fi

  output="$(printf '%s\n' "$SERVER_TRUST_PASSWORD" | "$keytool_bin" -list -v -keystore "$store_path" -storetype "$SERVER_TRUST_TYPE" 2>/dev/null || true)"
  [ -n "$output" ] || return 1
  mark_targets "$output"
}

detect_java() {
  local java_bin=""
  local settings=""
  local java_home=""
  local keytool_candidate=""

  JAVA_KEYTOOL=""

  command -v java >/dev/null 2>&1 || return 0
  java_bin="$(command -v java)"
  java_bin="$(readlink -f "$java_bin" 2>/dev/null || printf '%s\n' "$java_bin")"

  settings="$("$java_bin" -XshowSettings:properties -version 2>&1 || true)"
  [ -n "$settings" ] || return 0

  JAVA_DETECTED=yes
  JAVA_LABEL="$(printf '%s\n' "$settings" | awk -F= '/^[[:space:]]*java.vendor[[:space:]]*=/{v=$2} /^[[:space:]]*java.version[[:space:]]*=/{x=$2} END {gsub(/^[[:space:]]+|[[:space:]]+$/, "", v); gsub(/^[[:space:]]+|[[:space:]]+$/, "", x); print v " " x}')"
  java_home="$(printf '%s\n' "$settings" | awk -F= '/^[[:space:]]*java.home[[:space:]]*=/{gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2); print $2; exit}')"
  JAVA_CACERTS="${java_home:+$java_home/lib/security/cacerts}"

  if [ -n "$java_home" ]; then
    for keytool_candidate in \
      "$java_home/bin/keytool" \
      "$java_home/../bin/keytool"
    do
      if [ -x "$keytool_candidate" ]; then
        JAVA_KEYTOOL="$keytool_candidate"
        break
      fi
    done
  fi

  [ -f "$JAVA_CACERTS" ] || JAVA_CACERTS=""
}

audit_java_cacerts() {
  local output

  [ "$JAVA_DETECTED" = yes ] && [ -n "$JAVA_CACERTS" ] || return 0
  [ -n "${JAVA_KEYTOOL:-}" ] && [ -x "$JAVA_KEYTOOL" ] || return 0
  output="$(printf '%s\n' changeit | "$JAVA_KEYTOOL" -list -v -keystore "$JAVA_CACERTS" 2>/dev/null || true)"
  [ -n "$output" ] || return 0
  if printf '%s\n' "$output" | grep -F -q "$TARGET_ROOT_FP"; then
    JAVA_TARGET_ROOT_PRESENT=yes
  else
    JAVA_TARGET_ROOT_PRESENT=no
  fi
  if printf '%s\n' "$output" | grep -F -q "$TARGET_TLS_FP"; then
    JAVA_TARGET_TLS_PRESENT=yes
  else
    JAVA_TARGET_TLS_PRESENT=no
  fi
  if printf '%s\n' "$output" | grep -F -q "$TARGET_WSS_FP"; then
    JAVA_TARGET_WSS_PRESENT=yes
  else
    JAVA_TARGET_WSS_PRESENT=no
  fi
}

write_state() {
  local temp_file

  mkdir -p "$STATE_DIR"
  temp_file="$STATE_FILE.$$.tmp"
  umask 077
  {
    printf 'P1_USED=%s\n' "$P1_USED"
    printf 'PROFILE=%s\n' "$PROFILE"
    [ -n "$ENDPOINT" ] && printf 'ENDPOINT=%s\n' "$ENDPOINT"
    [ -n "$SERVER_TRUST_PATH" ] && printf 'SERVER_TRUST_TYPE=%s\nSERVER_TRUST_PATH=%s\n' "$SERVER_TRUST_TYPE" "$SERVER_TRUST_PATH"
    [ -n "$CLIENT_TLS_PATH" ] && printf 'CLIENT_TLS_TYPE=%s\nCLIENT_TLS_PATH=%s\n' "$CLIENT_TLS_TYPE" "$CLIENT_TLS_PATH"
    [ -n "$CLIENT_WSS_PATH" ] && printf 'CLIENT_WSS_TYPE=%s\nCLIENT_WSS_PATH=%s\n' "$CLIENT_WSS_TYPE" "$CLIENT_WSS_PATH"
    [ -n "$SOURCE_PATH" ] && printf 'SOURCE_TYPE=%s\nSOURCE_PATH=%s\n' "$SOURCE_TYPE" "$SOURCE_PATH"
    [ -n "$PAYLOAD_ID" ] && printf 'PAYLOAD_ID=%s\nPAYLOAD_CHANGE_AT=%s\n' "$PAYLOAD_ID" "$PAYLOAD_CHANGE_AT"
    printf 'TARGET_ROOT_PRESENT=%s\nTARGET_TLS_PRESENT=%s\nTARGET_WSS_PRESENT=%s\nSERVER_CERT_MODE=%s\nSERVER_CERT_TARGET_PRESENT=%s\nPRESERVE_WSS=%s\nJAVA_DETECTED=%s\n' "$TARGET_ROOT_PRESENT" "$TARGET_TLS_PRESENT" "$TARGET_WSS_PRESENT" "${SERVER_CERT_MODE:-unknown}" "$SERVER_CERT_TARGET_PRESENT" "${PRESERVE_WSS:-unknown}" "$JAVA_DETECTED"
    [ -n "$JAVA_CACERTS" ] && printf 'JAVA_CACERTS=%s\n' "$JAVA_CACERTS"
    printf 'JAVA_TARGET_ROOT_PRESENT=%s\nJAVA_TARGET_TLS_PRESENT=%s\nJAVA_TARGET_WSS_PRESENT=%s\nAUDIT_RESULT=%s\nAUDIT_TIMESTAMP=%s\n' "$JAVA_TARGET_ROOT_PRESENT" "$JAVA_TARGET_TLS_PRESENT" "$JAVA_TARGET_WSS_PRESENT" "$AUDIT_RESULT" "$(date '+%FT%T%z')"
  } > "$temp_file"
  mv -f "$temp_file" "$STATE_FILE"
  chmod 0644 "$STATE_FILE"
}

if [ "${P1CERT_LIB_ONLY:-0}" = 1 ]; then return 0 2>/dev/null || exit 0; fi
mkdir -p "$LOG_DIR" "$STATE_DIR"; LOG_FILE="$LOG_DIR/p1cert-audit-$(date '+%Y%m%d_%H%M%S').log"; log 'audit started'; log "docker_backend=$(docker_backend)"; load_payload; detect_source
if [ "$P1_USED" = yes ] && [ "$AUDIT_RESULT" != UNKNOWN ]; then SOURCE_CONTAINER="$(find_container)"; case "$SERVER_TRUST_TYPE" in PEM|pem|CER|cer|CRT|crt) audit_pem || { AUDIT_RESULT=UNKNOWN; log 'server trust PEM could not be inspected'; } ;; *) audit_store || { AUDIT_RESULT=UNKNOWN; log 'server trust store could not be inspected'; } ;; esac; fi
detect_java; [ "$AUDIT_RESULT" = UNKNOWN ] || audit_java_cacerts; write_state; log "audit finished result=$AUDIT_RESULT p1_used=$P1_USED"
printf 'P1CERT %s\nHost: %s\nP1: %s\nProfil: %s\nEndpoint: %s\n' "$P1CERT_VERSION" "$(hostname 2>/dev/null || printf UNKNOWN)" "$(yesno "$P1_USED")" "$PROFILE" "${ENDPOINT:-NIE WYKRYTO}"
printf 'Zaufanie serwera:\n  Typ: %s\n  Źródło: %s\n  Docelowy RootCA: %s\n  Docelowy SubCA TLS: %s\n  Docelowy SubCA WSS: %s\n' "$SERVER_TRUST_TYPE" "${SERVER_TRUST_PATH:-NIE WYKRYTO}" "$(yesno "$TARGET_ROOT_PRESENT")" "$(yesno "$TARGET_TLS_PRESENT")" "$(yesno "$TARGET_WSS_PRESENT")"
printf 'TLS klienta:\n  %s\nWSS klienta:\n  %s\n' "${CLIENT_TLS_PATH:-NIE WYKRYTO}" "${CLIENT_WSS_PATH:-NIE WYKRYTO}"
if [ -n "$PAYLOAD_ID" ]; then printf 'Payload: %s\nZmiana: %s\n' "$PAYLOAD_ID" "$PAYLOAD_CHANGE_AT"; else printf 'Payload: NIEZNANY (%s)\n' "${PAYLOAD_ERROR:-nie wykryto}"; fi
case "$SERVER_CERT_MODE" in preserve) printf 'Certyfikat serwera: ZACHOWAJ\n' ;; replace) printf 'Certyfikat serwera: target NIEZNANE\n' ;; *) printf 'Certyfikat serwera: NIEZNANE\n' ;; esac
if [ "$PRESERVE_WSS" = true ]; then printf 'WSS: ZACHOWAJ\n'; elif [ -n "$PRESERVE_WSS" ]; then printf 'WSS: polityka payloadu=%s\n' "$PRESERVE_WSS"; else printf 'WSS: NIEZNANE\n'; fi
printf 'Java: %s\nJava cacerts: %s\nDocelowy RootCA w Java cacerts: %s\nDocelowy SubCA TLS w Java cacerts: %s\nDocelowy SubCA WSS w Java cacerts: %s\nWynik audytu: %s\n' "$JAVA_LABEL" "${JAVA_CACERTS:-NIE WYKRYTO}" "$(yesno "$JAVA_TARGET_ROOT_PRESENT")" "$(yesno "$JAVA_TARGET_TLS_PRESENT")" "$(yesno "$JAVA_TARGET_WSS_PRESENT")" "$AUDIT_RESULT"
