# Changelog

## Unreleased

- Fix (Docker discovery): a relative certificate/keystore path of a service
  without `working_dir` is resolved when exactly one host file is reachable
  through a mount of that service (otherwise still reported as unmapped);
  a relative `*_FILE` password path uses `working_dir`. A keystore password
  also binds through the container file name and through the variable a
  password variable is set from (`KS_SECRET: ${P1_KEYSTORE_PASSWORD}`); the
  root helper binds the same way. A P1 file found only in a mounted
  directory, without a reference in the configuration, is reported in
  `plan` (`INFO ... pominięty, nie blokuje aplikacji`) and no longer blocks
  the application nor counts as a second user of an explicitly referenced
  file; a referenced P1 keystore that cannot be handled still refuses the
  whole application.
- Fix: `plan` refused Docker applications whose P1 keystore entry has an
  alias with spaces, brackets or `*` (`SKIP ...: alias wpisu P1 zawiera
  nieobsługiwane znaki`, e.g. P1ADAPTER with `*.ezdrowie.gov.pl (certum ov
  tls g2 r39 ca)`). The alias rule shared by `plan` and `apply-docker` now
  accepts every printable ASCII alias as Java writes it and still refuses
  the record separator `|`, control characters, non-ASCII bytes, `?`, a
  leading `-` or space, a trailing space and more than 128 characters. The
  alias stays unchanged and is compared literally.
- Docker Compose applications in `plan`, `run` and the root helper (stage
  E4; helper/library API 5, plan version 3 only for plans with Docker
  applications). `plan` offers each unambiguous application once (all its
  PEM/DER/JKS/PKCS12 P1 files together, restart only for an active unit)
  and keeps its files out of the classic targets. `run` recovers
  interrupted operations, then calls the new helper operation
  `apply-docker`, which re-derives the application from the unit, the files,
  the store passwords and contents itself, writes all files of the
  application as one journaled operation (`/var/lib/itgo-p1cert`, root-only,
  original owner/mode/SELinux context, descriptor-bound replacement),
  verifies them, restarts only the bound unit when it was running and checks
  that every compose service that ran before runs again in a container
  started after the restart (orphans and services not running before are not
  judged; an active unit without running containers and a unit in
  transition are refused); any failure restores all files (and restarts
  once with them). New helper operation and command `recover` for
  interrupted operations (SIGKILL, reboot): it restarts the unit only when
  the containers may have loaded the new files and the restart was
  approved, and never starts a stopped unit; `run` recovers first, also
  with a plan without Docker applications (`ping`: `DOCKER_PENDING`). The PKCS12 tool `p1cert-pkcs12.jar` is shipped in the
  payload, pinned by SHA-256 in installer and helper and installed
  root-owned; Java is never installed. The unprivileged E3 writer
  (`ez_dc_update_project`, `ez_tx_*`) is removed: only the helper writes.
  Classic targets, version 2 plans and the classic helper operations are
  unchanged.
- Docker Compose applications: PKCS12 keystores in the replacement mechanism
  (stage E3.1, still not connected to `run`). New Java 8 tool
  `java/P1certPkcs12.java` (`p1cert-pkcs12.jar`, built by `java/build.sh`)
  replaces the P1 `trustedCertEntry` through the Java KeyStore API: password
  on stdin, private keys never decrypted (encrypted key bags written back
  byte for byte, no key passwords needed), attributes and algorithms of the
  original kept and verified; refuses what it cannot carry over unchanged.
  PEM and PKCS12 of one application are updated as one operation with the
  E3 transaction. Needs a Java 8+ runtime on the server (never installed by
  P1CERT); otherwise PKCS12 targets are refused.
- Docker Compose applications: replacement mechanism for the P1 certificate
  (stage E3, not connected to `run`, the plan or restarts yet;
  `ez_dc_update_project`, library `ez_tx_*`, `ez_jks_replace_cert`). Uses the
  Nextcloud source and SHA-256 comparison of `plan`; replaces PEM (bytes of
  the source, chains kept), DER and the P1 `trustedCertEntry` of JKS
  keystores byte by byte (alias, other entries, private keys and password
  kept, digest recomputed); all files of one application as one operation
  with verified backups, atomic renames, verification from disk and full
  rollback; refuses the whole application for uncertain files, unusable
  sources and PKCS12 keystores (an OpenSSL export/import does not keep a
  Java 8 PKCS12 store; documented by tests). New test
  `tests/test_ezdrowie_docker_update.sh`; the JKS test builder moved to
  `tests/ezdrowie_fixtures.sh`.
- `p1cert ezdrowie discover`: read-only inspection of JKS and PKCS12
  keystores (stage E2). The store password is bound to the store by the
  compose configuration (password variable named after the variable that
  names the store or after the file, `<NAME>_FILE` secret files), read from
  `environment`/`env_file`/`.env` in memory only and passed to `openssl`/
  `iconv` on standard input. JKS v1/v2 (Java 8) is parsed without keytool
  and verified with its integrity digest; PKCS12 through `openssl pkcs12`
  (MAC, Java 8 RC2/3DES via `-legacy` on OpenSSL 3). Lists aliases,
  `PrivateKeyEntry`/`trustedCertEntry` and certificates, identifies the
  production `*.ezdrowie.gov.pl` certificate by identity and SHA-256
  (`P1: PEWNA/NIEPEWNA/CHRONIONY/BRAK`) and reports readable states
  (`BRAK_HASLA`, `HASLO_NIEJEDNOZNACZNE`, `HASLO_NIEPOPRAWNE`, `USZKODZONY`,
  `NIEOBSLUGIWANY`, `BRAK_INTEGRALNOSCI`). Nothing is modified; helper API
  4 and the classic Integration Platform handling are unchanged.
- `p1cert ezdrowie discover` (new, read-only): Docker Compose applications
  and the certificates/keystores they use. Detects compose v1
  (`docker-compose`) and v2 (`docker compose`) in systemd units, also
  through `/usr/bin/env`, plus compose projects no unit runs; selects the
  compose files like compose (`-f`, `COMPOSE_FILE`, default file +
  override), interpolates with the unit environment, `.env`/`--env-file`,
  resolves `env_file`, `environment`, bind mounts, named bind volumes and
  file secrets/configs to host paths, independent of application and file
  names; classifies files by content (PEM/DER X.509 with ezdrowie identity,
  JKS, PKCS12, JCEKS); lists password variable names, never values, and
  prints values only as plain paths; skips every directory whose name
  contains `old` (any case; `scan` keeps its exact `OLD` rule); refuses
  ambiguous configurations (shell, remote daemon options, several units per
  project, several default files, YAML anchors/merge keys, `extends`,
  `include`, multi-line values, unresolved variables, ...), and an
  ambiguous service makes its project ambiguous; every file is rated
  `PEWNY`/`NIEPEWNY`. No docker or compose
  command is run and nothing is changed. `scan`, `plan`, `run`, the helper
  and its API 4 are unchanged; Docker targets are not yet replaceable.
  New library section in `p1cert_ezdrowie_lib.sh` (`ez_dc_*`,
  `ez_store_type`) and tests `tests/test_ezdrowie_docker.sh`.
- `p1cert ezdrowie`: classic Integration Platform (Tomcat `p1-war`) support
  for certificates outside the installation. A systemd unit is detected and
  may be restarted when `SSL.patch` in
  `<installation>/apache-tomcat/webapps/p1-war/WEB-INF/appConfig.properties`
  of exactly the IntegrationPlatform installation the unit runs from
  (`WorkingDirectory`/`ExecStart`) names the certificate, e.g.
  `/srv/CERTYFIKATY/ezdrowieGovPl.cer` with
  `ExecStart=/srv/IntegrationPlatform_TST/apache-tomcat/bin/startup.sh`;
  the plan now shows `systemctl restart <unit>` instead of `NIE WYKRYTO`.
  Only an exact active entry counts (properties whitespace and CRLF
  trimmed); comments, other paths, prefixes/suffixes such as `.bak`,
  quotes, variables, command substitution, escapes and continuation lines
  never match, a second `SSL.patch` with another value disables the
  evidence, nothing is expanded or evaluated. The unit must run from exactly
  one installation: `WorkingDirectory`, every `ExecStart` command (one line
  per command or several blocks on one line), what `sh`/`bash` runs (a
  direct absolute script, or `-c` only as ONE simple command
  `[exec] /absolute/program [args]` without control operators, `cd`,
  builtins or assignments) and absolute arguments below the
  allowed roots must all name the same installation; two installations
  (`IntegrationPlatform_PI` vs `_PI2`), variables, `$(...)`, backticks,
  quotes and other shell syntax or options refuse the unit. A sibling
  installation, the certificate directory or a common parent such as `/srv`
  is never evidence. Rule B (certificate inside the installation) now
  requires the same unambiguous installation of the whole unit: a unit that
  also runs or references a second installation, or has a command that
  cannot be analysed, is no longer bound (commands outside any installation
  still do not matter). The restart target is
  still `systemd|<unit>`; `PLAN_VERSION=2` is unchanged. The root helper
  re-derives the installation from the unit and re-proves the binding on
  its own, before the replacement and again before the restart, under a
  narrow policy used only for this file: parents above the installation
  root-controlled (`root:root 775` accepted), installation tree and
  `appConfig.properties` owned by root or the unit's `User=` with group
  write only for root or that user's primary group (`itgo:itgo 775`
  accepted), never world writable, no symlink, one hard link, at most
  256 KiB, no NUL, read by name with `O_NOFOLLOW`/`O_NONBLOCK` between two
  device:inode checks (not descriptor-bound: a same-size A-B-A swap by the
  owner of `WEB-INF` is not detected by the read, see README). The
  existing `helper_node_trusted`/`helper_path_trusted` rules for unit,
  drop-in and environment files are unchanged. The WorkingDirectory/
  ExecStart analysis is shared by the old and the new rule
  (`ez_systemd_run_paths`, `ez_systemd_ip_root`); certificates inside an
  installation, exact paths in the unit configuration and Docker Compose
  behave as before.
- Helper contract API 4 (helper, library, caller and installer): the
  binding semantics above change the caller/library/helper contract.
  Operations, arguments and results are unchanged, but API 1, 2 and 3
  components (and unknown or malformed versions) next to API 4 components
  refuse to work (partial upgrade); re-run the installer.
- `p1cert ezdrowie`: certificate target directories may be owned by root or
  by the P1CERT user (the sudo caller, also for the scheduled run) and may be
  group-writable for the `root` group or the P1CERT user's group (e.g.
  `/srv/CERTYFIKATY` as `root:root 775` or `itgo:itgo 775`). World-writable
  directories, directories of other users and foreign writable groups are
  still refused (plan SKIP, helper REFUSED). `fs.protected_hardlinks=1` is
  recommended hardening, not a requirement. To stay safe in such
  directories, the helper now creates the replacement with `O_CREAT|O_EXCL`
  under an unpredictable name and applies content, owner, group, mode and
  SELinux context only through its open descriptor (`/proc/self/fd`), so
  these privileged operations cannot be redirected to a swapped-in inode.
  Targets are read only with `O_NOFOLLOW`/`O_NONBLOCK`; the pre-rename
  checks, the verification and the rollback are bound to the device:inode
  checked before, and a swap detected by them makes the operation fail
  (nothing renamed, or rollback refused). The final `mv -f -T` is a
  pathname-based rename without compare-and-swap, so a narrow window
  remains between the last target check and the rename: a user who can
  already modify the directory can, in that window, have a concurrent change
  of their own overwritten or make the operation fail (DoS). This is not a
  privilege escalation. `read` no longer follows a symlink swapped in after
  validation.
- Helper contract API 3 (helper, library, caller and installer): the helper
  depends on the library's target directory policy (`ez_target_dir_ok`) and
  the descriptor/inode bound replacement. Operations, arguments and results
  are unchanged, but an API 2 helper, library or caller next to API 3
  components refuses to work (partial upgrade); re-run the installer.
- `p1cert ezdrowie`: valid PEM certificate chains are supported (e.g.
  `ezdrowieGovPl.cer` and `ezdrowiegovpl_2026.pem`: leaf, intermediate CA,
  root CA) in scan, source collection, plan, run, backup and the root
  helper. A chain is accepted only when it contains nothing but
  `CERTIFICATE` blocks, starts with a non-CA, non-self-signed leaf, every
  following certificate is a CA that issued the previous one (name and
  signature verified with `openssl verify -partial_chain` against that CA
  only, OpenSSL 1.0.2 and 3.x) and it ends with the self-signed root;
  concatenated independent certificates, unrelated CAs, a wrong order, a
  missing root or forged/damaged intermediates are rejected with a reason.
  All decisions use the leaf; the complete verified chain is installed byte
  for byte, verified by leaf fingerprint and whole-file SHA-256, and rolled
  back to the exact previous bytes. A chain is never converted to DER and a
  local chain is never replaced by a single certificate. Single PEM/DER
  certificates are handled as before.
- `p1cert ezdrowie`: the operator-approved plan (`PLAN_VERSION=2`) binds the
  exact SHA-256 of the whole local file and of the whole source file, in
  addition to the leaf fingerprints. `run` skips a target whose local or
  source file changed in any byte since the plan (e.g. another intermediate
  or root with the same leaf, other line endings); a new plan is required.
  Plans with `PLAN_VERSION=1` are rejected - create a new plan after the
  upgrade.
- Helper contract API 2 (helper, library, caller and installer):
  `apply`/`apply-systemd`/`apply-compose` take the approved old-file and
  new-source SHA-256 as arguments. The helper verifies the stdin bytes
  before inspecting them, verifies its root-private copy of the current
  target before any change, and the existing check right before the atomic
  rename uses the same bytes, so a change after the plan or between the
  caller's checks and the helper is detected and not installed (except for
  the narrow final window between that check and the pathname-based
  rename, see the target directory entry above). Helper,
  library or caller of API 1 next to API 2 components refuse to work
  (partial upgrade), before any certificate operation.
- `p1cert ezdrowie`: directories whose complete component name is `OLD`
  (case-insensitive, at any depth, independent of the rest of the path) are
  treated as certificate archives. They are pruned from the scan (also in the
  helper's `find-candidates`), and every target below them is rejected by the
  shared path rule used by the plan parser and all helper operations, so such
  certificates are never scanned, planned or replaced. File and directory
  names that only contain "old" (`oldcerts`, `backup_old`,
  `old-ezdrowie.gov.pl-2025.crt`) are unchanged.

- Added the separate `p1cert ezdrowie` namespace for operator-approved
  replacement of local ezdrowie.gov.pl certificates (`/srv`, `/usr/local`,
  `/opt`) with the source certificate from Nextcloud `P1CERT_EZDROWIE`:
  `credentials`, `test`, `scan`, `plan`, `run`, `schedule`,
  `schedule-status` and `schedule-cancel`. Decisions use X.509 data only
  (validity, fingerprint, NotAfter, ezdrowie.gov.pl identity); the local path
  and file name are always preserved, every replacement is backed up and
  verified, and a failed restart rolls back with a single retry.
  Identity follows TLS semantics: DNS SANs are authoritative and the CN is
  only a fallback without DNS SAN; `*.ezdrowie.gov.pl` covers exactly one
  left-most label; the source is selected per local target. DER files must
  be exactly one certificate (no trailing data).
- Added the root-owned helper
  `/usr/local/libexec/itgo-p1cert/p1cert-ezdrowie-helper` with a dedicated
  `/etc/sudoers.d/itgo-p1cert-ezdrowie` entry and the
  `itgo-p1cert-ezdrowie.service` unit for the one-shot timer
  (`Persistent=false`, no catch-up after downtime). The helper offers only
  `apply`, `apply-systemd` and `apply-compose`: replacement, restart of a
  unit/compose service it proves to use the certificate, and rollback from
  its own copy of the old certificate happen in one privileged operation.
  There is no standalone restart or restore and no restart allowance. The
  helper fails closed when it, its library or their directories, the target
  directory, or the scheduler units are not root-controlled, and calls
  Docker with a clean environment (no `docker compose`). A rollback writes
  the old certificate back only over the exact bytes it installed; systemd
  restarts must stay active for a settle period; systemd binding evidence
  must come from root-controlled directories.
- `run` reports `PARTIAL` (non-zero exit) when some targets were skipped and
  `ROLLBACK_RESTART_FAILED` separately from `ROLLBACK`; a scheduled run never
  acts before the planned time; `plan`/`run`/`schedule` require `flock`;
  credential mode file and config directory permissions are enforced.
- The installer now creates `config/` and `backups/` with mode 0700 and no
  longer changes ownership of `config/` and `backups/` recursively; P1 CA
  commands (`audit`, `verify`, `update`, `status`) are unchanged.
- Caller, library and root helper share a contract version (helper API 1,
  reported by `helper ping`); a missing, older or newer helper is refused.
  The installer installs system files only into trusted root directories
  (`mv -f -T`, existing symlinks are never replaced), validates the complete
  sudoers configuration with revert, verifies `sudo -n` of the helper for the
  P1CERT user, validates the group name used in the service unit and reports
  `P1CERT ezdrowie system integration: READY` or `INCOMPLETE`.
- Added `p1cert_installer_public.sh --uninstall [user]`: disables and
  removes the one-shot timer, removes the service unit, the sudoers fragment,
  the root helper and library (directory only when empty), the own
  `/usr/local/bin/p1cert` link and the P1CERT directory. Only root-owned
  regular files with the P1CERT markers are removed; anything else is left
  and reported with a non-zero exit status.

- Added `update --java-only` and `update --with-keystore`. Automatic UPDATE
  now updates host Java cacerts and, when detected, an application JKS/PKCS12
  truststore; PEM/CER server-trust files remain untouched.
- Hardened UPDATE backups against path, scope and same-second collisions, and
  use a deterministic fingerprint-based alias when a preferred alias is
  already occupied by another certificate.
- UPDATE now returns a non-zero status for an incomplete or failed operation.
- Fixed preferred-alias selection so a free target alias is accepted correctly
  instead of being reported as unavailable during CA import.

- Java detection and Java cacerts handling are now host-only; container Java
  runtimes are ignored by both AUDIT and UPDATE.

- Added `CCP1SubCAWSS2025` as a third target CA alongside RootCA 2025 and
  SubCA TLS 2025.
- AUDIT now reports WSS CA presence in the application trust store and Java
  cacerts.
- UPDATE now imports the target WSS CA idempotently using alias
  `itgo-p1-subca-wss-2025`.
- Kept `PRESERVE_WSS=true` semantics unchanged: existing client WSS
  certificates are preserved.

## 0.1.3 - 2026-09-02

- Fixed certificate payload parsing compatibility across RHEL-family OpenSSL
  versions (including Oracle Linux 7.x/OpenSSL 1.0.x and Rocky Linux 9.x): the
  SHA-256 fingerprint field name is now matched case-insensitively.
- Made target certificate reading format-agnostic by trying PEM first and DER
  second, independently of the filename extension.

## 0.1.2 - 2026-09-02

- Fixed manifest.env line endings in p1-production-certs.zip from CRLF to LF so Linux validation works correctly.
## 0.1.1 - 2026-08-26

- Made AUDIT/VERIFY payload-driven: fingerprints are calculated from the
  versioned ZIP instead of stored in code.
- Added strict non-evaluating manifest parsing and safe ZIP path checks.
- Fixed wrapper operation through `/usr/local/bin/p1cert` symlinks.
- Added payload-aware RootCA, TLS CA, Java cacerts, server-certificate policy,
  and WSS policy reporting. UPDATE and SCHEDULE remain unimplemented.

## 0.1.0 - 2026-08-25

- Initial P1CERT module.
- Added read-only AUDIT/VERIFY for P1ADAPTER and P1CER certificate sources.
- UPDATE and SCHEDULE are not implemented.
