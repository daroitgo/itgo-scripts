#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_USER="${1:-itgo}"

export SOURCE_DIR="${SCRIPT_DIR}/payload"

if [[ ! -f "${SCRIPT_DIR}/payload/MASTER/master_installer.sh" ]]; then
  echo "ERROR: missing payload/MASTER/master_installer.sh"
  exit 1
fi

if [[ ! -d "${SOURCE_DIR}/UPGBUILDER/template" ]]; then
  echo "ERROR: missing payload/UPGBUILDER/template"
  exit 1
fi

chmod 0755 "${SCRIPT_DIR}/payload/MASTER/master_installer.sh" 2>/dev/null || true

echo "[INFO] ITGO offline bundle"
echo "[INFO] SCRIPT_DIR : ${SCRIPT_DIR}"
echo "[INFO] SOURCE_DIR : ${SOURCE_DIR}"
echo "[INFO] TARGET_USER: ${TARGET_USER}"

exec bash "${SCRIPT_DIR}/payload/MASTER/master_installer.sh" "${TARGET_USER}"
